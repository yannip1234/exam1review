#include <iostream>
#include "Q3.h"
using namespace std;

int main() {
	cout << cos(1,10) << endl;
	return 0;
}
