#ifndef Q3
#define Q3

float cos(float x, int y);
//Calculates the Taylor expansion of the cosine of angle x (express in radians). The function calculates the Taylor series up to element y

#endif