#ifndef Q2
#define Q2

int* mergeArray(int* a1, int* a2, int size1, int size2);

#endif
